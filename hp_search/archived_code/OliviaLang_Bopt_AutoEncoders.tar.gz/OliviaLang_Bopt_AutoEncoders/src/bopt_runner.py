'''
Runs Bayesian Optimization files

By Olivia Lang
Student Intern
Computational Biology
Target Sciences
olang@seas.upenn.edu

Date Created: 8 June 2018
Date Last Modified: 24 July 2018
'''


from slurm_helpers import slurm_help
import argparse
import pandas as pd
import os
import io_helpers
from shutil import copy

parser = argparse.ArgumentParser()
parser.add_argument('-i', '--input_file',
                    help='location of the input/parameter file')
parser.add_argument('-s', '--script',
                    help='path the script to run the optimization over',
                    default='bopt_ae.py')

args = parser.parse_args()

inputs = io_helpers.get_params("../configs/" + args.input_file, 'project_params')

config_file = "../configs/slurm_config.tsv"
python_path = inputs['python_path']
script = args.script
job_folder = inputs['job_folder'] + 'results/' + inputs['project_name'] + '/'

if not os.path.exists(job_folder):
    os.makedirs(job_folder)

copy("../configs/" + args.input_file, job_folder+'input.json')

# Load Config data
config_df = pd.read_table(config_file, index_col=0, comment='#')

# Retrieve SLURM configuration
queue = config_df.loc['queue']['assign']
num_gpus = config_df.loc['num_gpus']['assign']
mem = config_df.loc['mem']['assign']
walltime = config_df.loc['walltime']['assign']


command = [python_path, script] + ['-i', job_folder+'input.json']
s = slurm_help(command=command,
                queue=queue,
                num_gpus=num_gpus,
                walltime=walltime,
                mem=mem,
                script_file=os.path.join(job_folder, 'script_file.sh'),
                error_file=os.path.join(job_folder, 'log.txt'),
                output_file=os.path.join(job_folder, 'log.txt'))
s.submit_command()