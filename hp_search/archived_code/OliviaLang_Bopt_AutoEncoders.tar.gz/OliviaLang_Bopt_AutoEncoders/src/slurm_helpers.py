'''
Helper class used to create and submit SLURM jobs to 

By Jin Yao with later additions from Olivia Lang

sbatch --gres=gpu:1 --mem=16G -t 360 -o my_output_log.txt test_slurm.sh

Usage: Import only

    from slurm_helpers import slurm_help
    b = slurm_help(command)

    b.make_command()    # To make a python list of commands
    b.submit_command()       # Directly submit slurm jobs
'''

import argparse
import pandas as pd
import os

class slurm_help():
    def __init__(self, command, 
                 queue='hpc-gpu',
                 num_gpus=1,
                 mem='16G',
                 walltime='100',
                 script_file='script.sh', 
                 error_file='std_err.txt',
                 output_file='std_out.txt'):

        self.command = ' '.join(command)
        self.mem = mem
        self.queue = queue
        self.num_gpus = num_gpus
        self.walltime = walltime

        self.script_file = script_file
        self.error_file = error_file
        self.output_file = output_file

    def make_command(self):
        # command_list = ['/usr/local/slurm/bin/sbatch', 
        command_list = ['sbatch',
                        '-e', self.error_file,
                        '-o', self.output_file, 
                        '-t', self.walltime,
                        '--mem=%s'%(self.mem)]
        print(' '.join(command_list))                
        if self.queue == 'hpc-gpu':
            command_list += ["--gres=gpu:%s"%(self.num_gpus)]
        if self.queue == 'pts-gpu':
            command_list += ["--gres=gpu:%s"%(self.num_gpus),
                             "--partition=up-gpu"]
        command_list += [self.script_file]
        # print(' '.join(command_list))
        return command_list

    def make_script(self): # Make a script to save command
        # Write command in the file
        file = open(self.script_file, "w+")
        lines_of_text = ["#!/bin/bash", "hostname", self.command]
        file.writelines('\n'.join(lines_of_text))
        file.close()

    def submit_command(self):
        import subprocess
        submit_command = self.make_command()
        self.make_script()
        # print(' '.join(submit_command))
        p = subprocess.run(submit_command, stdout=subprocess.PIPE, universal_newlines=True)
        print(p.stdout)
    
def run_model(save_folder = "../results/", script = "Autoencoders.py", gpu=True, command_args = []):
    
    config_file = '../configs/slurm_config.tsv'
   
    # Load Config data
    config_df = pd.read_table(config_file, index_col=0, comment='#')
    python_path = config_df.loc['py_path']['assign']
    
    command = [python_path, script] + command_args + [' -s', save_folder]
    
    print (command)
    # RUN ON CPU
    if not gpu:
        os.system(' '.join(command))
        print ("Job Submitted on CPU")
        return
        
    # RUN ON GPU (and configure SLURM)    
    
    # Retrieve SLURM configuration
    queue = config_df.loc['queue']['assign']
    num_gpus = config_df.loc['num_gpus']['assign']
    mem = config_df.loc['mem']['assign']
    walltime = config_df.loc['walltime']['assign']
    
    s = slurm_help(command=command,
                    queue=queue,
                    num_gpus=num_gpus,
                    walltime=walltime,
                    mem=mem,
                    script_file=os.path.join(save_folder, 'script_file.sh'),
                    error_file=os.path.join(save_folder, 'log.txt'),
                    output_file=os.path.join(save_folder, 'log.txt'))
    s.submit_command()