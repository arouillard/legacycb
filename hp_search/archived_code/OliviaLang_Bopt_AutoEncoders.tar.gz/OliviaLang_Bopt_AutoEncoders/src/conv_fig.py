
'''

Creates convergence figure for many optimizer runs
Simply replace "TCGA" on line with your project prefix

By Olivia Lang
Student Intern
Computational Biology
Target Sciences
olang@seas.upenn.edu

'''


from glob import glob
import pandas as pd
import seaborn as sns
sns.set(color_codes=True)
import matplotlib.pyplot as plt
import matplotlib as mpl
mpl.rcParams['image.cmap'] = 'Oranges'
mpl.rcParams['lines.markersize'] = 4
mpl.rcParams['font.size'] = 14
mpl.rcParams['lines.color'] = [1, 102/255, 0]

# get all evaluations files
evals = glob('../results/TCGA_poster*/evaluations_file.txt')

X=[]
Y=[]
run = []

current_run = 1
# for each evaluation
for e in evals:
    runs = pd.read_csv(e, sep='\t').values
    # for each run in the evaluation
    Y_run = []
    X_run=[]
    current_run = current_run + 1
    for i in range(len(runs)):
        X_run.append(runs[i][0])
        Y_run.append(runs[i][1])
        run.append(current_run)
        if len(Y_run) > 1 and Y_run[-1] > Y_run[-2]:
            Y_run[-1] = Y_run[-2]

f = plt.figure(figsize=(9,6))
for i in range(len(X_run)):
    plt.plot(X[i],Y[i], color=[1, 102/255, 0], alpha=0.5)
ax = f.axes[0]

ax.set_xticks([0,5,10,15,20])
ax.set_xticklabels(['0','5','10','15','20'])
plt.ylabel("Best Loss")
plt.xlabel("Number of Optimizer Iterations")
plt.ylim(350,550)
plt.savefig('master_conv')