
'''

Bayesian Optimizer Template for any Model

Created by Olivia Lang
Student Intern
Computational Biology
Target Sciences
Contact: olang@seas.upenn.edu

'''

#%% IMPORT STATEMENTS
import argparse
import GPyOpt
import pandas as pd
import io_helpers
import os
import imageio
import time
import subprocess
from random import choices
import string
from glob import glob
import slurm_helpers
from GPy.kern.src.stationary import RatQuad

#%%Split Autoencoder parameters based on whether they are domain or constant
def split_params(params):
    constants = { k : v for k,v in params.items() if not isinstance(v,dict)}
    domain_variable_names = [k for k,v in params.items() if isinstance(v,dict)]
    
    def continuous(name):
        dom = {"name" : name, "type" : "continuous", "domain" : [0, 1]}
        _min, _max = params[name]["domain"];
        if params[name]["scale"] is "linear":
            scale_func = lambda x : (_max - _min)*x + _min # Linearly scaled
        else:
            scale_func = lambda x : _min * (_max / _min)**x # Logarithmic
        return dom, scale_func
    def discrete(name):
        vals = params[name]["domain"]
        _min, _max = min(vals), max(vals)
        # TODO: add option for logarithmically scaled
        dom = {"name" : name, "type" : "discrete", "domain" : [(v-_min)/(_max-_min) for v in vals]}
        scale_func = lambda x : (_max - _min)*x + _min # Linearly scaled
        return dom, scale_func
    def categorical(name):
        dom = {"name" : name, "type" : "categorical", "domain" : params[name]["domain"]}
        scale_func = lambda x : x # no scaling
        return dom, scale_func
        
    switcher = {
            "continuous" : continuous,
            "discrete" : discrete,
            "categorical" : categorical
            }
    
    scale_functions = {}
    domain = []
    for name in domain_variable_names:
        dom,sf = switcher.get(params[name]['type'], lambda: "Invalid Type")(name)
        scale_functions[name] = sf
        domain.append(dom)
    
    return domain, domain_variable_names, scale_functions, constants

#%% BAYESIAN OPTIMIZATION CODE

# Function to Optimize
def f(d):
    # Make domain dict
    # TODO: will likely need to switch things up with d.flatten() if considering multi-dimensional variables
    domain_dict = { name : scaling_functions[name](val) for name,val in dict(zip(dvn,d.flatten())).items()}
    
    # Map from domain dict to actual values
    for var in domain_mappings:
        if var in domain_dict:
            domain_dict[var] = domain_mappings[var][int(domain_dict[var])]
    
    # Make folder for this run with random name
    # NOTE: In AE BO, this name was appended by information pertaining to the AE, but 
    #        it is important that the unique string not be replaced.
    file_id = ''.join(choices(string.ascii_uppercase + string.digits, k=5))
    model_folder = save_folder + file_id + '/'
    os.makedirs(model_folder)
    
    # Save params to file
    io_helpers.save_run_params_to_file({**domain_dict, **const}, model_folder)
    
    # Execute Model on GPU w/ slurm using static function in autoencoder class
    print ("Submitting Job")
    
    #~~~~~~~~~~~~~~~~~~~~~ TO DO INSTRUCTIONS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # After you've refactored your model. You should only have to change the 
    # one line of code below this comment block
    # The parameters for your model have been saved to model_folder/input.json.
    # Update the line of code below to reflect your model's script and any 
    # command arguments in addition to the required '-s save_folder' that your 
    # script may have.
    #~~~~~~~~~~~~~~~~~~~~~~~~ END OF TODO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    slurm_helpers.run_model(save_folder = model_folder, script = 'my_model.py', command_args = ['--any_additional cmd_line_argument', '--that_you may_have'])
    print ("Job Sucessfully Run")
    
    # Wait until output.json file has been created
    success = io_helpers.wait_for_completion(model_folder)
    if not success:
        raise RuntimeError('Error attempting to execute autoencoder on SLURM')
    print ("Job Completed on SLURM")
    
    # Get results from Model
    evaluation = io_helpers.get_run_eval_from_file(model_folder)
    return evaluation[0]

#%% PARSE ARGUMENTS
parser = argparse.ArgumentParser()
parser.add_argument('-i', '--input_file',
                    help='location of the input/parameter file')
args = parser.parse_args() 
input_file = args.input_file


#%% SET UP FOLDERS
proj_params = io_helpers.get_params(input_file,'project_params')
global save_folder
save_folder = proj_params['job_folder'] + 'results/' + proj_params['project_name'] + '/'


#%% Create Instance of the Optimizer
# Get and split params
model_params = io_helpers.get_params(input_file, 'model_params')
global dvn, const, scaling_functions, domain_mappings
d,dvn,scaling_functions,const = split_params(model_params)
const['save_folder'] = save_folder # adds save_folder to constants
domain_mappings = io_helpers.get_domain_mappings()
for var in domain_mappings:
     if var in const:
            print ("cat Var: "+str(const[var]))
            const[var] = domain_mappings[var][int(const[var])]

bopt_params = io_helpers.get_params(input_file, 'bopt_params')
# Does initial exploration on the data
# Make kernel
kernel = RatQuad(len(d), variance = 2, power=4)
opt_model = GPyOpt.methods.BayesianOptimization(f, domain=d, kernel=kernel, **bopt_params)
print ("INITIALIZED")


#%% Run Optimization
run_params = io_helpers.get_params(input_file, 'run_params')

opt_model.run_optimization(**run_params, verbosity=True, save_models_parameters= True, 
                           report_file =save_folder+"report_file.txt",
                           evaluations_file=save_folder+"evaluations_file.txt",
                           models_file=save_folder+"models_file.txt")

print("Plotting Optimization Convergence...")
opt_model.plot_convergence(save_folder+'conv')
print ("Done")
