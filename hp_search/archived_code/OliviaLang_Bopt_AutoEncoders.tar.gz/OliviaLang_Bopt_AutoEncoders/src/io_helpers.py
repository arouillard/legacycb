
'''

Helper functions for reading and writing files for bayesian optimizer

Created by Olivia Lang
Student Intern
Computational Biology
Target Sciences
Contact: olang@seas.upenn.edu

'''

from glob import glob
import json
import time
import subprocess

#%% FUNCTIONS TO GET INPUT PARAMETERS AND DOMAIN
def get_params(input_file, param_type):
    print (input_file)
    with open(input_file) as f:
        data = json.loads(f.read())
    return data[param_type]
    
def get_domain_mappings():
    with open("../configs/domain_mappings.json") as f:
        data = json.loads(f.read())
    return data
    
def save_run_params_to_file(param_dict, save_folder = '../results/'):
    with open(save_folder+"input.json", 'w') as fp:
        json.dump(param_dict, fp)
    
def get_run_params_from_file(save_folder = '../results/'): 
    with open(save_folder + "input.json", 'r') as fp:
        param_dict = json.loads(fp.read())
    return param_dict
    
def save_run_eval_to_file(evaluation, save_folder = '../results/'):
    with open(save_folder + "output.json", 'w') as fp:
        json.dump(evaluation, fp)
        
def get_run_eval_from_file(save_folder): 
    with open(glob(save_folder[:-1] + "*/output.json")[0], 'r') as fp:
        evaluation = json.loads(fp.read())
    return evaluation
    
def wait_for_completion(save_folder):
    # https://stackoverflow.com/questions/136168/get-last-n-lines-of-a-file-with-python-similar-to-tail
    def tail():
        f = glob(save_folder[:-1]+"*/log.txt")
        if len(f) is not 0:
            lines = subprocess.Popen(['tail', '-n', '5', f[0]], stdout=subprocess.PIPE).stdout.readlines()
            lines = [s.decode("utf-8") for s in lines]
            return lines
        else:
            return [""]
    completed = False
    # Wait until output.json file has been created
    while not completed:
        t=tail()
        is_success = (len(glob(save_folder[:-1]+"*/output.json")) is not 0)
        completed = is_success \
                    or any(["slurmstepd: error" in n for n in t]) \
                    or any(["see above for traceback" in n for n in t])
        time.sleep(5)
    return is_success