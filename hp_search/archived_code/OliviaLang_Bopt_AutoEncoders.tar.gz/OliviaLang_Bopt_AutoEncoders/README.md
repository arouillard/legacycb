# Bayesian Optimizer to Supplement Autoencoders

This project was developed to bring Bayesian Optimization to GSK's CB team. 
In the process, much of the existing code for developing autoencoders was refactored, creating a scaffolding for future model design.

## Getting Started

These instructions will get you a copy of the project up and running for use. More detailed instructions and tutorials are located in the 
OneNote Notebooks. 

### Anaconda Environment

#### Option One

This project involved a few different python packages. To start, you may want to use Olivia's Anaconda environment which already has them installed. 
This is located at:

```
/GWD/bioinfo/projects/cb01/users/olivia/anaconda/
```

#### Option Two
If you would like to outfit your own Anaconda environment 
for use with the optimizer, please see the OneNote Page "Setting Up Anaconda Environment."

### Installing

You may download this repository and save it to your project folder either via cloning or as a zip file.

### Running the Optimizer

There are written tutorials on three opjectives pertaining to the optimizer: running it on existing autoencoders, developing 
new autoencoders within the code scaffolding, and applying the optimizer to new models. These three objectives are explained 
in more depth in their respective OneNote pages.


## Built With

* [GPy](https://github.com/SheffieldML/GPy)
* [GPyOpt](https://github.com/SheffieldML/GPyOpt)
* [Keras](https://github.com/keras-team/keras)
* [Tensorflow](https://github.com/tensorflow/tensorflow)

## Authors

* **Olivia Lang** - *Bayesian Optimizer* - olivia.x.lang@gsk.com, olang@seas.upenn.edu
* **Jin Yao** - *Constructed Variational Autoencoder*
